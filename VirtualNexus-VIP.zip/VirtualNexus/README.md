<p align="center"><img src="docs/banner.svg" alt="Virtual Nexus"/></p>

# Virtual Nexus

Container Android limpo para **adicionar jogos (APK), OBBs e permissões** e jogar dentro do app. Interface Jetpack Compose com animações e console de logs.

## Recursos (v2.0 VIP)
- Ícone próprio, logo, imagem hero e capas (PNG) + sons e vibração
- Splash animada com som, 4 abas (Início, Jogos, Logs, VIP)
- Biblioteca salva no aparelho, favoritos, busca, ordenação
- Clonar jogo (outro save/conta), limpar dados, remover
- Temas de cor, backup, logs compartilháveis
- Release otimizado (R8 + shrink de recursos)

## Recursos básicos
- Splash animada e tema escuro
- Importar APK (lê nome, pacote e permissões)
- Importar vários OBBs por jogo
- Botões Jogar / Remover / ver permissões
- Console de logs em tempo real

## Build
1. Abra no Android Studio (JDK 17) e sincronize o Gradle.
2. `./gradlew assembleDebug`  → `app/build/outputs/apk/debug/`

## Motor
Usa [BlackBox](https://github.com/FBlackBox/BlackBox) (via JitPack) para virtualização. Confira a versão no repositório dele; se a API mudar, ajuste só `Engine.kt` e `NexusApp.kt`.

## Aviso
Use apenas com jogos que você possui. Jogos online com anti-cheat/anti-tamper podem não rodar ou banir contas.
