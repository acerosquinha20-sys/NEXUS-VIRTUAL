package com.virtualnexus.app

import androidx.compose.runtime.mutableStateListOf
import java.text.SimpleDateFormat
import java.util.*

object NexusLog {
    val lines = mutableStateListOf<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private fun add(tag: String, m: String) { lines.add("${fmt.format(Date())} $tag $m"); if (lines.size > 200) lines.removeAt(0) }
    fun i(m: String) = add("[INFO]", m)
    fun e(m: String) = add("[ERRO]", m)
    fun ok(m: String) = add("[ OK ]", m)
}
