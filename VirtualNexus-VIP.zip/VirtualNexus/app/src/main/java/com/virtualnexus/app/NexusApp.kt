package com.virtualnexus.app

import android.app.Application
import android.content.Context
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.app.configuration.ClientConfiguration

class NexusApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        try {
            BlackBoxCore.get().doAttachBaseContext(base, object : ClientConfiguration() {
                override fun getHostPackageName() = base.packageName
            })
        } catch (t: Throwable) { NexusLog.e("Falha ao anexar motor: ${t.message}") }
    }
    override fun onCreate() {
        super.onCreate()
        Prefs.load(this); Fx.init(this)
        try { BlackBoxCore.get().doCreate() } catch (t: Throwable) { NexusLog.e("Falha ao iniciar motor: ${t.message}") }
    }
}
